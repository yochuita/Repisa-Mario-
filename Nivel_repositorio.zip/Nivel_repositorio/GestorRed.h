#ifndef GESTOR_RED_H
#define GESTOR_RED_H

#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

class GestorRed {
private:
    const char* ssid;
    const char* password;
    const char* mqttBroker;
    int mqttPort;

    WiFiClient espClient;
    PubSubClient mqttClient;

    void conectarWiFi();
    void reconectarMQTT();

public:
    GestorRed(const char* wifiSSID, const char* wifiPass, const char* broker, int port);
    void iniciar();
    void mantenerConexion();
    void publicarTelemetria(const char* topic, const char* cajonId, float distancia);
    
    // ¡Añade estas dos líneas que faltaban en el .h!
    void configurarCallback(MQTT_CALLBACK_SIGNATURE);
    void loopMQTT();
};

#endif