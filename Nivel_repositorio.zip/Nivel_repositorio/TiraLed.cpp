#include "TiraLed.h"

TiraLed::TiraLed(uint8_t pin, uint16_t cantidad) {
    pinPin = pin;
    numLeds = cantidad;
    leds = new CRGB[numLeds];
}

void TiraLed::comenzar() {
    // Nota: Reemplaza WS2812B por WS2811 si usas esa variante específica de la imagen
    FastLED.addLeds<WS2812B, 4, GRB>(leds, numLeds); 
    FastLED.setBrightness(120);
    apagar();
}

void TiraLed::actualizarPorEstado(String estado) {
    if (estado == "VACIO") {
        fill_solid(leds, numLeds, CRGB::Blue);     // Azul para vacío
    } 
    else if (estado == "OPERATIVO") {
        fill_solid(leds, numLeds, CRGB::Green);    // Verde para normal
    } 
    else if (estado == "CRITICO_SOBRECARGA") {
        fill_solid(leds, numLeds, CRGB::Red);      // Rojo para sobrecarga
    } 
    else if (estado == "ERROR_SENSOR") {
        fill_solid(leds, numLeds, CRGB::Yellow);   // Amarillo para error
    } 
    else {
        apagar();
    }
    FastLED.show();
}

void TiraLed::encenderBlanco() {
    fill_solid(leds, numLeds, CRGB::White);
    FastLED.show();
}

void TiraLed::apagar() {
    fill_solid(leds, numLeds, CRGB::Black);
    FastLED.show();
}