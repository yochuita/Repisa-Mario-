#include "SensorUltrasonico.h"
#include "GestorRed.h"
#include "TiraLed.h"

// Instancia de la clase TiraLed (Pin GPIO 4 y 5 LEDs asignados al cajón)
TiraLed tiraCajon1(6,4);
// Instancias de Objetos
SensorUltrasonico sensor(4, 5); /
GestorRed red("FKN PR", "RAZORZ10XD", "broker.emqx.io", 1883);

// Configuración de Tópico y Cajón
const char* TOPIC_TELEMETRIA = "repisa/cajones/cajon_1/telemetria";
const char* CAJON_ID         = "cajon_1";

// Temporización No Bloqueante (millis)
unsigned long ultimoEnvio = 0;
const unsigned long INTERVALO_ENVIO = 3000;

void setup() {
    Serial.begin(115200);
    sensor.begin();
    red.iniciar();
    tiraCajon1.comenzar();
    
    // Vinculamos el callback a través de la clase GestorRed
    red.configurarCallback(callbackMensaje);}

void loop() {
    red.mantenerConexion();
    red.loopMQTT(); // Reemplaza al mqttClient.loop() directo

    unsigned long tiempoActual = millis();
    if (tiempoActual - ultimoEnvio >= INTERVALO_ENVIO) { // <- Cambiado a ultimoEnvio
        ultimoEnvio = tiempoActual;                       // <- Cambiado a ultimoEnvio
        float distancia = sensor.leerDistancia();
        red.publicarTelemetria(TOPIC_TELEMETRIA, CAJON_ID, distancia);
    }
}
// Función que se ejecuta automáticamente al recibir un mensaje por MQTT
void callbackMensaje(char* topic, byte* payload, unsigned int length) {
    String mensaje = "";
    for (unsigned int i = 0; i < length; i++) {
        mensaje += (char)payload[i];
    }

    // Control de la tira LED según lo que llegue de Node-RED
    if (mensaje == "ON") {
        tiraCajon1.encenderBlanco(); // O puedes encenderla según el estado actual
        Serial.println("Pick-to-Light: Luz ENCENDIDA");
    } 
    else if (mensaje == "OFF") {
        tiraCajon1.apagar();
        Serial.println("Pick-to-Light: Luz APAGADA");
    }
}