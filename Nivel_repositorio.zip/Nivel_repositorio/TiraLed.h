#ifndef TIRA_LED_H
#define TIRA_LED_H

#include <Arduino.h>
#include <FastLED.h>

class TiraLed {
private:
    uint8_t pinPin;
    uint16_t numLeds;
    CRGB* leds;

public:
    TiraLed(uint8_t pin, uint16_t cantidad);
    void comenzar();
    void actualizarPorEstado(String estado);
    void encenderBlanco();
    void apagar();
};

#endif