#include "GestorRed.h"

GestorRed::GestorRed(const char* wifiSSID, const char* wifiPass, const char* broker, int port)
    : ssid(wifiSSID), password(wifiPass), mqttBroker(broker), mqttPort(port), mqttClient(espClient) {}

void GestorRed::conectarWiFi() {
    if (WiFi.status() == WL_CONNECTED) return;
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
    }
}

void GestorRed::reconectarMQTT() {
    while (!mqttClient.connected()) {
        String clientId = "ESP32_Cajon_" + String(random(0xffff), HEX);
        if (mqttClient.connect(clientId.c_str())) {
            // ¡Importante! Aquí nos suscribimos al tópico de control del cajón 1
            mqttClient.subscribe("repisa/cajones/cajon_1/control");
            break;
        }
        delay(2000);
    }
}

void GestorRed::iniciar() {
    conectarWiFi();
    mqttClient.setServer(mqttBroker, mqttPort);
}

void GestorRed::mantenerConexion() {
    if (WiFi.status() != WL_CONNECTED) {
        conectarWiFi();
    }
    if (!mqttClient.connected()) {
        reconectarMQTT();
    }
    mqttClient.loop();
}

void GestorRed::publicarTelemetria(const char* topic, const char* cajonId, float distancia) {
    StaticJsonDocument<200> doc;
    doc["cajon_id"] = cajonId;

    if (distancia < 0) {
        doc["distancia_cm"] = -1.0;
        doc["error"] = true;
        doc["codigo_error"] = 500;
    } else {
        doc["distancia_cm"] = distancia;
        doc["error"] = false;
        doc["codigo_error"] = 0;
    }

    char buffer[200];
    serializeJson(doc, buffer);
    mqttClient.publish(topic, buffer);
}

void GestorRed::configurarCallback(MQTT_CALLBACK_SIGNATURE) {
    mqttClient.setCallback(callback);
}

void GestorRed::loopMQTT() {
    mqttClient.loop();
}