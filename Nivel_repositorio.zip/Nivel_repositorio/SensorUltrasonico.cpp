#include "SensorUltrasonico.h"

SensorUltrasonico::SensorUltrasonico(uint8_t trig, uint8_t echo) 
    : trigPin(trig), echoPin(echo) {}

void SensorUltrasonico::begin() {
    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);
    digitalWrite(trigPin, LOW);
}

float SensorUltrasonico::leerDistancia() {
    digitalWrite(trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigPin, LOW);

    long duracion = pulseIn(echoPin, HIGH, 30000);

    if (duracion == 0) return -1.0; 

    float distancia = duracion * 0.0343 / 2.0;

    if (distancia < 2.0 || distancia > 400.0) return -1.0; 

    return distancia;
}