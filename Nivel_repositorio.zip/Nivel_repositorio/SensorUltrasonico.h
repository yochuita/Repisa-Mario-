#ifndef SENSOR_ULTRASONICO_H
#define SENSOR_ULTRASONICO_H

#include <Arduino.h>

class SensorUltrasonico {
private:
    uint8_t trigPin;
    uint8_t echoPin;

public:
    SensorUltrasonico(uint8_t trig, uint8_t echo);
    void begin();
    float leerDistancia();
};

#endif